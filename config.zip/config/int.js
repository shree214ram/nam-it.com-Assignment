const intConfig = {
  IMAGEURL: './assets/images/',
  BASE_URL: 'http://localhost:3000'
};

module.exports = intConfig;

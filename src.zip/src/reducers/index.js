import { combineReducers } from 'redux';
import { localeReducer as locale } from 'react-localize-redux';
import jobs from './JobsReducer';
import employee from './EmployeesReducer';

export default combineReducers({
  locale,
  jobs,
  employee
});

import React from 'react';
import { Router, Route, IndexRoute, hashHistory } from 'react-router';
// import injectTapEventPlugin from 'react-tap-event-plugin';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import App from '../App';
import EmployeesIndex from '../Employees/EmployeesIndex';
import JobsIndex from '../Jobs/JobsIndex';

// injectTapEventPlugin();

const Routes = () => (
  <MuiThemeProvider>
    <Router history={hashHistory}>
      <Route path="/" component={App}>
        <IndexRoute component={JobsIndex} />
        <Route path="/Employees" component={EmployeesIndex} />
        <Route path="/Jobs" component={JobsIndex} />
      </Route>
    </Router>
  </MuiThemeProvider>
);

export default Routes;

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Typography from '@material-ui/core/Typography';
// import { hashHistory } from 'react-router';
import { getEmpData } from '../../actions/EmployeesAction';
// import empData from '../../../config/empData.json';

// import Employees from './Employees';
import Panel from './Panel';
// import Panel1 from './Panel1';
// import './Employees.scss';

class EmployeesIndex extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  componentWillMount() {
    if (this.props.employee.employee && !this.props.employee.employee.length) {
      this.getEmpData();
    }
  }
  componentDidMount() {
  }
  componentWillReceiveProps(nextProps) {
    console.log(this.props, 'this.props');
    console.log(nextProps, 'nextProps');
  }
  getEmpData = () => {
    // this.props.dispatch(
    //   getEmpData()
    // );
  }
  render() {
    console.log(this.props, 'this.props>>>>');
    return (
      <div>
        {/* <Employees /> */}
        <Typography variant="subtitle1">Search Employee</Typography>
        <Panel data={this.props.employee.employee || []} />
        {/* <Panel /> */}
      </div>
    );
  }
}
function mapStateToProps(state) {
  return { employee: state.employee };
}
export default connect(mapStateToProps)(EmployeesIndex);

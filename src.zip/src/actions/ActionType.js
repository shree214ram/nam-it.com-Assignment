export const EmployeesType = {
  EMPLOYE_LIST_SUCCESS: 'EMPLOYE_LIST_SUCCESS'
};

export const JobsType = {
  JOBS_SUCCESS: 'JOBS_SUCCESS',
  JOBS_FAILED: 'JOBS_FAILED',
  SET_JOBS_TEXT_FIELD: 'SET_JOBS_TEXT_FIELD'
};

export const ErrorType = {
  ERROR_LOG: 'ERROR_LOG'
};

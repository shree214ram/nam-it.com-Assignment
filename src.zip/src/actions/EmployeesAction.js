// import axios from 'axios';
import { EmployeesType } from './ActionType';
import empData from '../../config/empData.json';

export function getEmpData() {
  return (dispatch) => {
    dispatch({
      type: EmployeesType.EMPLOYE_LIST_SUCCESS,
      employee: empData.employee
    });
  };
}

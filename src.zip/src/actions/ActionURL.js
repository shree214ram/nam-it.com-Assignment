export const LoginUrl = {
  AUTHENTICATE: 'http://localhost:9000/auth'
};
export const ChatBotUrl = {
  CHATBOT: 'https://api.wit.ai/message?v=04/10/2017&q='
};

import React, { Component } from 'react';
import { connect } from 'react-redux';
import Typography from '@material-ui/core/Typography';
// import { hashHistory } from 'react-router';
import { getJobsData } from '../../actions/JobsAction';
// import Jobs from './Jobs';
// import Panel from './Panel';
import Panel1 from './Panel';
// import './Jobs.scss';

class JobsIndex extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  componentWillMount() {
    console.log(this.props, 'this.prop----s');
    if (this.props.jobs.jobs && !this.props.jobs.jobs.length) {
      this.getJobsData();
    }
  }
  componentDidMount() {
  }
  componentWillReceiveProps(nextProps) {
    console.log(this.props, 'this.props');
    console.log(nextProps, 'nextProps?????');
  }
  getJobsData = () => {
    // this.props.dispatch(
    //   getJobsData()
    // );
  }
  render() {
    console.log(this.props, 'this.prop9999----s');
    const data = (this.props.jobs.Jobs && this.props.jobs.Jobs.jobs ? this.props.jobs.Jobs.jobs : []);
    console.log(data, 'datapppp----s');
    return (
      <div>
        {/* <Jobs /> */}
        <Typography variant="subtitle1">Search Jobs</Typography>
        <Panel1 data={data} />
      </div>
    );
  }
}

function mapStateToProps(state) {
  return { jobs: state.jobs };
}
export default connect(mapStateToProps)(JobsIndex);

/**
 * @file Header Component.
 * @author Sunny
 */
import React from 'react';

class Header extends React.Component {
  render() {
    return (
      <div>Header</div>
    );
  }
}

export default Header;

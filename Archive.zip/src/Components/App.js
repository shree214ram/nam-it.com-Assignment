import React, { Component } from 'react';
import AppHeader from './AppHeader';

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      open: false
    };
  }
  render() {
    return (
      <div>
        <AppHeader />
        <div style={{ textAlign: 'center' }}>
          {this.props.children}
        </div>
      </div>
    );
  }
}

export default App;


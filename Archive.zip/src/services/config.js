/**
 * Created by Sunny.
 */
export const server = 'http://localhost:3000';

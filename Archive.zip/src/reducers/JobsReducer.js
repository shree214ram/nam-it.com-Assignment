import { JobsType } from '../actions/ActionType';
import jobData from '../../config/jobsInfo.json';

const DEFAULT_STATE = {
  Jobs: jobData
};

const setJob = (state, action) => {
  const newState = [];
  Object.assign(newState, state);
  newState.Jobs = action.Jobs;
  return newState;
};

export default function reducer(state = DEFAULT_STATE, action) {
  switch (action.type) {
    case JobsType.JOBS_LIST_SUCCESS:
      return setJob(state, action);
    default:
      return state;
  }
}

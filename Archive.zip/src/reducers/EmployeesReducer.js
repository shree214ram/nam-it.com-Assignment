import { EmployeesType } from '../actions/ActionType';
import empData from '../../config/empData.json';

const DEFAULT_STATE = {
  employee: empData
};

const setEmployee = (state, action) => {
  const newState = {};
  Object.assign(newState, state);
  newState.employee = action.employee;
  return newState;
};

export default function reducer(state = DEFAULT_STATE, action) {
  switch (action.type) {
    case EmployeesType.EMPLOYE_LIST_SUCCESS:
      return setEmployee(state, action);
    default:
      return state;
  }
}

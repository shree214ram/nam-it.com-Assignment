const config = __APP_CONFIG__;

export default config;


export const Configs = {
  JOBSCONFIG: {
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache'
    }
  }
  // CHATBOTCONFIG: {
  //   headers: {
  //     'Content-Type': 'application/json',
  //     'Cache-Control': 'no-cache'
  //   },
  //   dataType: 'jsonp'
  // }
};

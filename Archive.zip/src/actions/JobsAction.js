// import axios from 'axios';
import { JobsType } from './ActionType';
import jobData from '../../config/jobsInfo.json';

export function getJobsData() {
  return (dispatch) => {
    dispatch({
      type: JobsType.JOBS_LIST_SUCCESS,
      jobs: jobData.jobs
    });
  };
}

const devConfig = {
  MASTER_TOKEN: '4xNcFf2lL2ILDutSCgHYvw5is4AkXQAZ',
  IMAGEURL: './assets/images/',
  BASE_URL: 'http://localhost:3000'
};

module.exports = devConfig;

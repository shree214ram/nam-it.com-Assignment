const prodConfig = {
  IMAGEURL: './assets/images/',
  BASE_URL: 'http://{hostname}:8083'
};

module.exports = prodConfig;
